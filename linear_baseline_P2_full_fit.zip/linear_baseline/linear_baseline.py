#!/usr/bin/env python3
"""Small, reproducible linear baselines for all five P2 validation boards."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import anndata as ad
import h5py
import numpy as np
from scipy import sparse
from sklearn.linear_model import LinearRegression, Ridge


# ===== PATHS TO CHANGE (or override with --data-root/--denoised-root/--output-root) =====
HERE = Path(__file__).resolve().parent
DEFAULT_DATA_ROOT = HERE.parent                 # original E*.h5ad files
DEFAULT_DENOISED_ROOT = HERE.parent / "exp1_data-/runs/exp1/outputs"
DEFAULT_OUTPUT_ROOT = HERE / "outputs"
DENOISED_LAYER = "exp1_pvaed_reconstruction"    # .X in those files is ORIGINAL
# ================================================================================

SEED = 20261028
OUTPUT_CELLS = 2000
READ_ROWS = 256
BOARD_SPECS = {
    "T1:val": ("temporal", 10.5, [(8.5, "E8.5_RNA.h5ad"), (9.5, "E9.5_RNA.h5ad")]),
    "T2:embryo:val_interp": ("temporal", 7.5, [(6.75, "E6.75.h5ad"), (7.25, "E7.25.h5ad"), (8.0, "E8.0.h5ad")]),
    "T2:heart:val_interp": ("temporal", 8.5, [(8.25, "E8.25_late.h5ad"), (8.75, "E8.75.h5ad"), (9.5, "E9.5.h5ad")]),
    "T2:heart:val_extrap": ("temporal", 10.5, [(8.25, "E8.25_late.h5ad"), (8.75, "E8.75.h5ad"), (9.5, "E9.5.h5ad")]),
    "T3:gata4": ("perturb", None, ["E9.5.h5ad", "E9.5_mab21l2_ko.h5ad", "E8.75.h5ad"]),
}
FILE_STEMS = {
    "T1:val": "T1_val_E10.5",
    "T2:embryo:val_interp": "T2_embryo_val_interp_E7.5",
    "T2:heart:val_interp": "T2_heart_val_interp_E8.5",
    "T2:heart:val_extrap": "T2_heart_val_extrap_E10.5",
    "T3:gata4": "T3_gata4_val_E8.75",
}


def decode(values):
    return [v.decode("utf-8") if isinstance(v, bytes) else str(v) for v in values]


def file_path(name, version, args):
    if version == "raw":
        path = args.data_root / name
    else:
        path = args.denoised_root / name.replace(".h5ad", ".pvaed.h5ad")
    if not path.is_file():
        raise FileNotFoundError(f"Missing {version} input: {path}")
    return path


def selected_rows(n, count, name):
    seed = SEED + int(hashlib.sha256(name.encode()).hexdigest()[:8], 16)
    return np.sort(np.random.default_rng(seed).choice(n, min(n, count), replace=False))


def read_labels(h5, rows):
    item = h5["obs/celltype"]
    if isinstance(item, h5py.Group):
        cats = np.asarray(decode(item["categories"][:]), dtype=object)
        codes = item["codes"][rows]
        return np.asarray([cats[i] if i >= 0 else "unknown" for i in codes], dtype=object)
    return np.asarray(decode(item[rows]), dtype=object)


def read_values(h5, version, rows, columns):
    node = h5["X"] if version == "raw" else h5[f"layers/{DENOISED_LAYER}"]
    if isinstance(node, h5py.Group):
        # Released original files are CSC; the KO file has a dense X. The
        # temporary sparse matrix is discarded before another stage is read.
        kind = node.attrs["encoding-type"]
        shape = tuple(int(x) for x in node.attrs["shape"])
        cls = sparse.csc_matrix if kind == "csc_matrix" else sparse.csr_matrix
        if kind not in ("csc_matrix", "csr_matrix"):
            raise ValueError(f"Unsupported sparse X encoding: {kind}")
        mat = cls((node["data"][:], node["indices"][:], node["indptr"][:]), shape=shape)
        result = mat[rows, :][:, columns].toarray().astype(np.float32)
        del mat
        return result
    # Bounded row chunks keep dense PVAED reconstructions from being loaded in full.
    result = np.empty((len(rows), len(columns)), dtype=np.float32)
    for start in range(0, len(rows), 64):
        stop = min(start + 64, len(rows))
        result[start:stop] = np.asarray(node[rows[start:stop], :], dtype=np.float32)[:, columns]
    return result


def load_sample(name, version, genes, args, count=OUTPUT_CELLS, need_coords=False):
    path = file_path(name, version, args)
    with h5py.File(path, "r") as h5:
        names = decode(h5["var/_index"][:])
        index = {gene: i for i, gene in enumerate(names)}
        missing = [gene for gene in genes if gene not in index]
        if missing:
            raise ValueError(f"{path}: {len(missing)} required genes missing; first: {missing[:5]}")
        columns = np.asarray([index[gene] for gene in genes], dtype=np.int64)
        node = h5["X"] if version == "raw" else h5[f"layers/{DENOISED_LAYER}"]
        n = int(node.attrs["shape"][0]) if isinstance(node, h5py.Group) else node.shape[0]
        rows = selected_rows(n, count, name)
        if version == "denoised":
            original = args.data_root / name
            if original.is_file():
                with h5py.File(original, "r") as raw:
                    raw_names = decode(raw["var/_index"][:])
                    if names != raw_names or decode(h5["obs/_index"][rows]) != decode(raw["obs/_index"][rows]):
                        raise ValueError(f"{path}: denoised gene/cell order differs from original {original}")
        x = read_values(h5, version, rows, columns)
        labels = read_labels(h5, rows)
        xyz = np.asarray(h5["obsm/spatial_3D"][rows, :3], dtype=np.float32) if need_coords else None
    if not np.isfinite(x).all() or np.min(x) < -1e-5:
        raise ValueError(f"{path}: selected expression has negative or nonfinite values")
    if xyz is not None and not np.isfinite(xyz).all():
        raise ValueError(f"{path}: selected coordinates are nonfinite")
    return x, labels, xyz


def stage_stats(name, version, genes, args, need_coords, keep_cells=True):
    """Use every cell for fitted means and geometry; sample only output anchors."""
    path = file_path(name, version, args)
    with h5py.File(path, "r") as h5:
        names = decode(h5["var/_index"][:])
        index = {gene: i for i, gene in enumerate(names)}
        missing = [gene for gene in genes if gene not in index]
        if missing:
            raise ValueError(f"{path}: {len(missing)} required genes missing; first: {missing[:5]}")
        columns = np.asarray([index[gene] for gene in genes], dtype=np.int64)
        node = h5["X"] if version == "raw" else h5[f"layers/{DENOISED_LAYER}"]
        n = int(node.attrs["shape"][0]) if isinstance(node, h5py.Group) else node.shape[0]
        labels = read_labels(h5, slice(None))
        if len(labels) != n:
            raise ValueError(f"{path}: expression and cell labels have different lengths")
        unique, codes = np.unique(labels, return_inverse=True)
        counts = np.bincount(codes, minlength=len(unique))
        group_sums = np.zeros((len(unique), len(genes)), dtype=np.float64)
        rows = selected_rows(n, OUTPUT_CELLS, name) if keep_cells else None

        if version == "denoised":
            original = args.data_root / name
            if original.is_file():
                with h5py.File(original, "r") as raw:
                    if names != decode(raw["var/_index"][:]) or decode(h5["obs/_index"][:]) != decode(raw["obs/_index"][:]):
                        raise ValueError(f"{path}: denoised gene/cell order differs from original {original}")

        anchor_x = np.empty((len(rows), len(genes)), dtype=np.float32) if keep_cells else None
        if isinstance(node, h5py.Group):
            kind = node.attrs["encoding-type"]
            if kind not in ("csc_matrix", "csr_matrix"):
                raise ValueError(f"{path}: unsupported sparse X encoding {kind}")
            cls = sparse.csc_matrix if kind == "csc_matrix" else sparse.csr_matrix
            mat = cls((node["data"][:], node["indices"][:], node["indptr"][:]),
                      shape=tuple(int(v) for v in node.attrs["shape"]))
            panel = mat if np.array_equal(columns, np.arange(mat.shape[1])) else mat[:, columns]
            if not np.isfinite(panel.data).all() or (len(panel.data) and panel.data.min() < -1e-5):
                raise ValueError(f"{path}: expression contains negative or nonfinite values")
            membership = sparse.csr_matrix(
                (np.ones(n, dtype=np.float32), (codes, np.arange(n))),
                shape=(len(unique), n))
            group_sums[:] = (membership @ panel).toarray()
            if keep_cells:
                anchor_x[:] = panel[rows, :].toarray()
        else:
            # PVAED layers and the released KO X are dense. Read every row in
            # bounded chunks, never materialising the full RNA reconstruction.
            for start in range(0, n, READ_ROWS):
                stop = min(start + READ_ROWS, n)
                block = np.asarray(node[start:stop, :], dtype=np.float32)[:, columns]
                if not np.isfinite(block).all() or np.min(block) < -1e-5:
                    raise ValueError(f"{path}: invalid expression in rows {start}:{stop}")
                local_codes = codes[start:stop]
                for code in np.unique(local_codes):
                    group_sums[code] += block[local_codes == code].sum(axis=0, dtype=np.float64)
                if keep_cells:
                    left, right = np.searchsorted(rows, [start, stop])
                    if left < right:
                        anchor_x[left:right] = block[rows[left:right] - start]

        xyz = None
        radius = None
        if need_coords:
            all_xyz = np.asarray(h5["obsm/spatial_3D"][:, :3], dtype=np.float32)
            if len(all_xyz) != n or not np.isfinite(all_xyz).all():
                raise ValueError(f"{path}: invalid spatial_3D")
            center = np.median(all_xyz, axis=0)
            radius = float(np.quantile(np.linalg.norm(all_xyz - center, axis=1), 0.9))
            if not np.isfinite(radius) or radius <= 0:
                raise ValueError(f"{path}: spatial radius must be positive")
            if keep_cells:
                xyz = all_xyz[rows]

    means = {str(label): group_sums[i] / counts[i] for i, label in enumerate(unique)}
    global_mean = group_sums.sum(axis=0) / n
    return {"x": anchor_x, "labels": labels[rows] if keep_cells else None,
            "xyz": xyz, "means": means, "global_mean": global_mean,
            "radius": radius, "fit_cells": n}


def linear_stage_predict(target, stages, version, genes, args, need_coords):
    anchor_time, anchor_name = min(stages, key=lambda e: (abs(e[0] - target), -e[0]))
    entries = [(time, name, stage_stats(name, version, genes, args, need_coords,
                                       keep_cells=(name == anchor_name)))
               for time, name in stages]
    anchor = next(stats for _, name, stats in entries if name == anchor_name)
    x = anchor["x"].copy()
    labels = anchor["labels"]
    for label in np.unique(labels):
        observed = [(time, stats["means"][str(label)]) for time, _, stats in entries
                    if str(label) in stats["means"]]
        if len(observed) < 2:
            continue
        times = np.asarray([time for time, _ in observed], dtype=np.float64).reshape(-1, 1)
        means = np.asarray([mean for _, mean in observed], dtype=np.float64)
        model = LinearRegression().fit(times, means)
        predicted_mean = model.predict(np.asarray([[target]]))[0]
        # Shift real anchor cells, retaining their within-type heterogeneity.
        delta = predicted_mean - anchor["means"][str(label)]
        x[labels == label] = np.maximum(x[labels == label] + delta, 0).astype(np.float32)
    xyz = None
    if need_coords:
        time_array = np.asarray([t for t, _, _ in entries], dtype=np.float64).reshape(-1, 1)
        log_radius = np.log(np.asarray([e["radius"] for _, _, e in entries], dtype=np.float64))
        model = LinearRegression().fit(time_array, log_radius)
        predicted_radius = float(np.exp(model.predict([[target]])[0]))
        ratio = np.clip(predicted_radius / anchor["radius"], 0.5, 2.0)
        center = np.median(anchor["xyz"], axis=0)
        xyz = ((anchor["xyz"] - center) * ratio + center).astype(np.float32)
    return x, xyz, {"anchor_stage": anchor_time,
                    "fit_cells_by_file": {name: stats["fit_cells"] for _, name, stats in entries},
                    "model": "per-celltype linear mean shift; linear log-radius for T2"}


def perturb_predict(files, version, genes, args):
    wt9 = stage_stats(files[0], version, genes, args, True, keep_cells=False)
    ko9 = stage_stats(files[1], version, genes, args, True, keep_cells=False)
    wt875 = stage_stats(files[2], version, genes, args, True)
    # The two E9.5 files use incompatible cell-type vocabularies (only two
    # exact labels overlap), so fit one cross-gene response instead of
    # pretending their annotations define paired cell types.
    model = Ridge(alpha=10.0).fit(
        wt9["global_mean"][:, None], ko9["global_mean"] - wt9["global_mean"])
    # This learns the observed Mab21l2 response only. It cannot identify a
    # Gata4-specific causal effect from one unrelated knockout.
    x = wt875["x"]
    response = model.predict(x.reshape(-1, 1)).reshape(x.shape)
    predicted = np.maximum(x + response, 0).astype(np.float32)
    return predicted, wt875["xyz"], {
        "model": "cross-gene ridge linear response from Mab21l2 KO",
        "fit_cells_by_file": {files[0]: wt9["fit_cells"], files[1]: ko9["fit_cells"],
                              files[2]: wt875["fit_cells"]}}


def predict_board(board, version, args, panels):
    info = panels[board]
    kind, target, sources = BOARD_SPECS[board]
    if kind == "temporal":
        x, xyz, details = linear_stage_predict(target, sources, version, info["genes"], args, info["needs_coords"])
    else:
        x, xyz, details = perturb_predict(sources, version, info["genes"], args)
    n = min(OUTPUT_CELLS, info["max_cells"], len(x))
    if n < info["min_cells"]:
        raise ValueError(f"{board}: only {n} output cells, minimum {info['min_cells']}")
    x = x[:n]
    xyz = None if xyz is None else xyz[:n]
    validate_arrays(board, x, xyz, info)
    return x, xyz, details


def validate_arrays(board, x, xyz, info):
    if x.ndim != 2 or x.shape[1] != len(info["genes"]):
        raise ValueError(f"{board}: expression shape is wrong: {x.shape}")
    if not info["min_cells"] <= x.shape[0] <= info["max_cells"]:
        raise ValueError(f"{board}: cell count outside official range")
    if not np.isfinite(x).all() or np.min(x) < 0:
        raise ValueError(f"{board}: expression must be finite and nonnegative")
    if info["needs_coords"]:
        if xyz is None or xyz.shape != (len(x), 3) or not np.isfinite(xyz).all():
            raise ValueError(f"{board}: spatial_3D must be finite n_cells x 3")
    elif xyz is not None:
        raise ValueError(f"{board}: T1 must not include coordinates")


def write_prediction(board, version, args, panels):
    x, xyz, details = predict_board(board, version, args, panels)
    a = ad.AnnData(X=x)
    a.var_names = panels[board]["genes"]
    a.obs_names = [f"pred_{i:05d}" for i in range(len(x))]
    if xyz is not None:
        a.obsm["spatial_3D"] = xyz
    out = args.output_root / version / (FILE_STEMS[board] + ".h5ad")
    out.parent.mkdir(parents=True, exist_ok=True)
    a.write_h5ad(out, compression="gzip")
    validate_file(out, board, panels)
    print(f"READY {board} [{version}] -> {out}", flush=True)
    return {"board": board, "version": version, "file": str(out), "cells": len(x), **details}


def validate_file(path, board, panels):
    info = panels[board]
    a = ad.read_h5ad(path, backed="r")
    try:
        if list(a.var_names) != info["genes"]:
            raise ValueError(f"{path}: gene names/order do not match official {board} panel")
        if "celltype" in a.obs:
            raise ValueError(f"{path}: celltype should not be submitted")
        for start in range(0, a.n_obs, 128):
            block = np.asarray(a.X[start:start + 128], dtype=np.float32)
            xyz = np.asarray(a.obsm["spatial_3D"][start:start + 128, :3], dtype=np.float32) if info["needs_coords"] else None
            if not info["needs_coords"] and "spatial_3D" in a.obsm:
                raise ValueError(f"{path}: T1 has spatial_3D")
            # Cell count is checked against full n_obs separately below.
            if block.ndim != 2 or block.shape[1] != len(info["genes"]) or not np.isfinite(block).all() or np.min(block) < 0:
                raise ValueError(f"{path}: invalid expression at rows {start}:...")
            if info["needs_coords"] and (xyz.shape != (len(block), 3) or not np.isfinite(xyz).all()):
                raise ValueError(f"{path}: invalid spatial_3D")
        if not info["min_cells"] <= a.n_obs <= info["max_cells"]:
            raise ValueError(f"{path}: cell count outside official range")
    finally:
        a.file.close()


def proxy_metrics(x, xyz, truth_x, truth_xyz):
    return {
        "mean_expression_mae": float(np.mean(np.abs(x.mean(axis=0) - truth_x.mean(axis=0)))),
        "gene_std_mae": float(np.mean(np.abs(x.std(axis=0) - truth_x.std(axis=0)))),
        "spatial_radius_relative_error": float(abs(radius(xyz) / radius(truth_xyz) - 1)),
    }


def radius(xyz):
    return float(np.quantile(np.linalg.norm(xyz - np.median(xyz, axis=0), axis=1), 0.9))


def proxy_compare(args, panels):
    # These are released TRAIN stages held out locally, never official P2 truth.
    proxies = [
        ("embryo_E7.25", "T2:embryo:val_interp", 7.25,
         [(6.75, "E6.75.h5ad"), (8.0, "E8.0.h5ad")], "E7.25.h5ad"),
        ("heart_E8.75", "T2:heart:val_interp", 8.75,
         [(8.25, "E8.25_late.h5ad"), (9.5, "E9.5.h5ad")], "E8.75.h5ad"),
    ]
    report = {"note": "Every source-stage cell contributes to fitted statistics; 2000 raw target cells are sampled for this local diagnostic. These are not official P2 scores or statistical significance.", "proxies": {}}
    for label, board, target, sources, truth_file in proxies:
        genes = panels[board]["genes"]
        truth_x, _, truth_xyz = load_sample(truth_file, "raw", genes, args, need_coords=True)
        result = {}
        for version in ("raw", "denoised"):
            x, xyz, _ = linear_stage_predict(target, sources, version, genes, args, True)
            result[version] = proxy_metrics(x, xyz, truth_x, truth_xyz)
        result["denoised_minus_raw"] = {k: result["denoised"][k] - result["raw"][k] for k in result["raw"]}
        report["proxies"][label] = result
    out = args.output_root / "proxy_comparison.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(f"Local proxy comparison -> {out}")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["predict", "validate", "compare"])
    parser.add_argument("--data-root", type=Path, default=DEFAULT_DATA_ROOT)
    parser.add_argument("--denoised-root", type=Path, default=DEFAULT_DENOISED_ROOT)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT_ROOT)
    parser.add_argument("--version", choices=["raw", "denoised", "both"], default="both")
    parser.add_argument("--board", choices=["all", *BOARD_SPECS], default="all")
    args = parser.parse_args()
    panels = json.loads((HERE / "panels.json").read_text())
    boards = list(BOARD_SPECS) if args.board == "all" else [args.board]
    if args.action == "compare":
        proxy_compare(args, panels)
    elif args.action == "predict":
        versions = ["raw", "denoised"] if args.version == "both" else [args.version]
        manifest = [write_prediction(board, version, args, panels) for version in versions for board in boards]
        out = args.output_root / "manifest.json"
        previous = json.loads(out.read_text()) if out.is_file() else []
        combined = {(item["board"], item["version"]): item for item in previous}
        combined.update({(item["board"], item["version"]): item for item in manifest})
        out.write_text(json.dumps(list(combined.values()), ensure_ascii=False, indent=2) + "\n")
    else:
        versions = ["raw", "denoised"] if args.version == "both" else [args.version]
        for version in versions:
            for board in boards:
                path = args.output_root / version / (FILE_STEMS[board] + ".h5ad")
                validate_file(path, board, panels)
                print(f"VALID {board} [{version}] -> {path}")


if __name__ == "__main__":
    main()
