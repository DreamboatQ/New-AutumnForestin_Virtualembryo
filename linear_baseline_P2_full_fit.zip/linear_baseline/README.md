# Virtual Embryo P2 线性回归基线

本包只含 `linear_baseline.py`、`panels.json`、`requirements.txt`、`comparison_preview.json` 和本文档。ZIP **不含原始数据或去噪数据**。云端有完整的 **9 个原版和 9 个去噪文件**时，代码会对三个任务的 **5 个 P2 验证榜单**分别生成官网可上传的 `.h5ad`；原版和去噪版各生成一套。本地只下载了 **7 个去噪空间文件**，仅用于预检；这不缩减云端的 T1 训练和提交范围。

**全量拟合说明：**本修订版对每个榜单所用公开训练文件的**全部细胞**计算细胞类型基因均值、全局基因均值与空间尺度，再拟合线性回归。没有“仅用 2,000 个细胞训练”的限制。`manifest.json` 的 `fit_cells_by_file` 会逐文件记录实际参与拟合的细胞数。提交文件仍只生成 **2,000 个预测细胞**，这是输出样本数，符合各榜单官网范围；它不等于拟合时使用的细胞数。原始版与去噪版用相同的输出抽样细胞。

如果云端已有较早的 `linear_baseline_P2.zip`，它是 2,000 细胞抽样拟合版。请上传新的 **`linear_baseline_P2_full_fit.zip`** 到 `/mnt/workspace/`，执行 `cd /mnt/workspace && unzip -o linear_baseline_P2_full_fit.zip` 覆盖代码后，再运行本版。新旧版本输出文件名相同，重新运行会覆盖旧预测文件。

## 1. 最先修改：三个数据路径

在 Linux 云端终端中，解压 ZIP 后进入 `linear_baseline` 文件夹，修改下面三个变量的 **等号右边**：

```bash
RAW_DIR="/mnt/workspace"                                  # 9 个原始 E*.h5ad 所在目录
DENOISED_DIR="/mnt/workspace/exp1_data-/runs/exp1/outputs" # 9 个 *.pvaed.h5ad 所在目录
OUT_DIR="/mnt/workspace/linear_baseline_results"            # 预测结果输出目录
```

这三个变量通过命令行传入；无需改 Python 代码。另一台平台只改这三行。若原版或去噪版缺失，可以先只运行已有的版本。Python 文件顶部也集中列出了默认路径。

**重要：去噪文件的 `.X` 仍是原始数据。** 程序读取 `layers["exp1_pvaed_reconstruction"]`，并保持两个版本使用相同的细胞抽样种子、基因面板、回归规则和输出细胞数。

## 2. 安装与运行

建议 Python 3.10–3.12。下面均在解压后的 `linear_baseline` 目录执行：

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

运行前先设置上方三行路径。**本地只有原版数据时**：

```bash
python linear_baseline.py predict \
  --version raw \
  --data-root "$RAW_DIR" \
  --output-root "$OUT_DIR"

python linear_baseline.py validate \
  --version raw \
  --output-root "$OUT_DIR"
```

**云端 9 个去噪文件齐全时**，用同一代码和参数生成第二套完整预测，包括 T1：

```bash
python linear_baseline.py predict \
  --version denoised \
  --data-root "$RAW_DIR" \
  --denoised-root "$DENOISED_DIR" \
  --output-root "$OUT_DIR"

python linear_baseline.py validate \
  --version denoised \
  --output-root "$OUT_DIR"
```

两个版本都在同一平台时可以运行 `--version both`，但前提是 9 个去噪文件也已在 `DENOISED_DIR`。每次运行都会在 `$OUT_DIR/raw/` 或 `$OUT_DIR/denoised/` 覆盖对应的预测文件；请在提交前保留你想上传的版本。本地 7 个去噪空间文件不足以运行去噪版的默认全套 `predict`，但可以运行下面的 `compare` 和单独的 T2/T3 榜单。

## 3. P2 官网上传对应关系

登录[提交页面](https://virtualembryo.ai/challenge/account/submissions)，在页面选择**对应的 P2/Validation submission target**，然后上传下表同一行的单个文件。**不要上传这个代码 ZIP，也不要把 5 个文件再打成一个 ZIP 提交。**

| 页面选择的榜单 | `$OUT_DIR/raw/` 或 `$OUT_DIR/denoised/` 内的文件 |
| --- | --- |
| T1:val | `T1_val_E10.5.h5ad` |
| T2:embryo:val_interp | `T2_embryo_val_interp_E7.5.h5ad` |
| T2:heart:val_interp | `T2_heart_val_interp_E8.5.h5ad` |
| T2:heart:val_extrap | `T2_heart_val_extrap_E10.5.h5ad` |
| T3:gata4 | `T3_gata4_val_E8.75.h5ad` |

程序生成后会重读每个文件检查官方基因**名称及顺序**、细胞数、非负有限表达、T2/T3 的 `obsm["spatial_3D"]`。T1 不带坐标；所有文件不带 `obs["celltype"]`。榜单基因面板与细胞数上下限固定在随包提供的 `panels.json`，来源是[官网面板下载页](https://virtualembryo.ai/challenge/data)和[官网面板索引](https://virtualembryo.ai/challenge/panels/index.json)，下载时间为 2026-10-28。若官网更新提交要求，应重新核对面板。

官网当前说明：P3 已开放，**P2 冻结榜单**与仍在使用的 **Validation 榜单**分开。若团队已领取 P2 验证答案，或已有首个 P3 正式提交被接受，全队将不能再提交 P2。程序只生成文件，不访问或提交答案，不会触发这个状态；实际可选择的提交目标以登录后页面为准。[官方说明](https://virtualembryo.ai/challenge/account/submissions)

## 4. 原版与去噪版的本地对照

两版数据都就绪后：

```bash
python linear_baseline.py compare \
  --data-root "$RAW_DIR" \
  --denoised-root "$DENOISED_DIR" \
  --output-root "$OUT_DIR"
```

生成 `$OUT_DIR/proxy_comparison.json`。它把已公开的 **E7.25 胚胎**和 **E8.75 心脏**分别临时留作目标，用其它公开训练阶段的**全部细胞**拟合；两版预测都对照**相同的 2,000 个原始目标细胞**。其中 `denoised_minus_raw` 小于 0 表示该误差指标改善。指标仅包括基因均值误差、基因标准差误差和空间半径误差，是快速诊断，**不是官方评分或显著性检验**。由于去噪实验没有修改空间坐标，两版的空间半径结果预期基本相同。

已经用下载目录找到的 7 个真实去噪空间文件做过一次**局部预检**，完整数值见 `comparison_preview.json`。云端全套运行仍使用 9 个文件：

| 本地代理目标 | 均值误差，原版 → 去噪版 | 标准差误差，原版 → 去噪版 | 空间半径误差 |
| --- | ---: | ---: | ---: |
| E7.25 胚胎 | 0.1193 → 0.1164 | 0.1747 → 0.4123 | 两版均为 0.3504 |
| E8.75 心脏 | 0.2480 → 0.2307 | 0.2696 → 0.5021 | 两版均为 0.6573 |

基因均值误差略有改善，但标准差误差明显变大。这提示重建可能改变了细胞间变异，不能根据均值单项就判定去噪有效；这里没有统计显著性检验。本地缺少 E8.5_RNA 和 E9.5_RNA 两份去噪文件，故本地未运行去噪版 T1。**云端文件齐全时，上面的默认命令会运行去噪版 T1。**

T1 只有两个公开训练阶段；若再留出一个，就没有足够阶段拟合时间斜率。T3 只有一个公开 KO 类型，不能用另一种公开 KO 做真正的跨基因留出检验。所以这两题的主要比较依据仍是官网 P2 Validation 的同榜单分数。记下两个版本各自的提交记录和完整分项指标，比较时只在**同一榜单**内比较。

## 5. 方法与结论边界

- **T1/T2 表达**：按细胞类型计算公开训练阶段的基因均值，以发育时间做普通线性回归；把预测的均值变化加到一个真实阶段的抽样细胞上，保留细胞内的表达差异并裁掉负值。新出现的细胞类型无法由这条直线生成。
- **T2 空间**：对空间点云的 90% 半径取对数后随时间做线性回归，缩放参考点云，保留局部邻接的大致结构。各阶段坐标未配准，因此不直接对逐细胞的 x/y/z 做线性回归。
- **T3 Gata4**：用已公开 Mab21l2 KO 与配对 WT 的 500 个基因均值，把每个基因作为一个样本，以 WT 表达均值拟合 KO 表达差的 Ridge 线性回归，再施加到 E8.75 WT；空间坐标沿用 WT。两份 E9.5 文件的细胞类型命名体系几乎不重合，不能按同名类型逐一配对。只有一种公开 KO，无法识别真正的 Gata4 特异响应，因此这是弱基线，不能把 T3 分数解读为去噪对 Gata4 因果预测的证明。

这个实验思路**适合做初筛**：同一个简易预测器、相同数据划分与提交格式，比较输入表达是否让结果变好。但只看 P2 一个验证榜单的单次分数不能证明“显著提升”，也不能证明重建值是生物学真值。还要考虑去噪可能抹掉稀有细胞或 KO 效应；正式结论需要独立胚胎/批次的重复验证、置信区间，以及各任务分项指标一致改善。不要为看起来更好的 P2 分数反复调去噪超参数，避免验证集过拟合。

由于公开阶段之间没有逐细胞配对，线性回归拟合的是**由全部细胞计算出来的阶段/细胞类型统计量**；不能把“用了全部细胞”误解为每个细胞都有跨阶段监督标签。全量读取增加 I/O 时间，尤其是云端两份 32,285 基因的稠密去噪 RNA，但不会额外生成大量训练中间文件。

本包的依赖安装会生成一个 `.venv` 目录，但它不在 ZIP 中；预测运行只生成每榜单一个 `.h5ad`、一个 `manifest.json`，执行本地比较时再生成一个 JSON 报告。
